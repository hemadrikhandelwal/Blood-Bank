<?php
	// This will make universal connection to database
	$con=mysqli_connect("localhost","root","","ecommerce");
	session_start();
?>
<div>
	<form method="post" action="">
		<table>
			<tr>
				<td>Email :</td>
				<td> <input type="text" name="email" placeholder="Enter email" required/></td>
			</tr>
			<tr>
				<td >Password : </td>
				<td ><input type="password" name="pass" placeholder="Enter password" required/></td>
			</tr>
			<tr>
				<td colspan="2"><input type="submit" name="login" value="login" /></td>
			</tr>
		</table>
	</form>
</div>
	<?php
		if(isset($_POST['login']))
		{
			$email=$_POST['email'];
			$pass=$_POST['pass'];
			$q_login="select * from customers where customer_email='$email' AND customer_pass='$pass'";
			//echo $q_login;
			$run_login=mysqli_query($con,$q_login);
			$count_login=mysqli_num_rows($run_login);
			if($count_login==0)
			{
				//here goes error
				echo "<script>alert('Wrong email or password.')</script>";
				exit(); //so that code of rest of page is not executed 
			}
			else
			{
				
					//this will store log in session very imp
					$_SESSION['customer_email']=$email;
					//showing message of login
					echo "<script>alert('You logged in succesfully.')</script>";
					//reload any other page that you want to load
					echo "<script>window.open('customer/my_account.php','_self')</script>";
			}
		}
	?>
</div>